package com.egjson;

import java.io.*;
import com.fasterxml.jackson.databind.ObjectMapper;

public class WriteJSONEg {

 public static void main (String[] args ) throws Exception{

		//Address[]
    Address[] addrs =  {new Address("MBC1", "TVM", 645762),
    		new Address("MBC2", "TVM", 457862),
    };
    
    
    Person obj = new Person("Arun", 25,  addrs);
		
		ObjectMapper mapper = new ObjectMapper();
		
		FileOutputStream fos = new FileOutputStream("person.json");
		
		mapper.writeValue(fos,  obj);
		
		System.out.println("JSON File has been created");
		
	}
}

