package Test11;

//to print characters individually from a string using multi threading concept
class PrintChars extends Thread {

	String string1 = "This is Multithreading";

	@Override
	public void run() {
		try {
			System.out.println("Thread is :");
			for (int i = 0; i < string1.length(); i++) {
				System.out.print(string1.charAt(i)+" ");

				Thread.sleep(30);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}


}

public class MultiThreadingEg2 {

	static String string1 = "Hi Arun, How are you!!";

	public static void main(String[] args) {

		try {

			PrintChars thread = new PrintChars();
			thread.start();
			for (int i = 0; i < string1.length(); i++) {
				System.out.print(string1.charAt(i)+" ");
				Thread.sleep(30);
			}

		}

		catch (Exception e) {
			e.printStackTrace();
		}
	}

}
