package com.example.demo_rest;

import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;

@RestController
public class DemoRestController {
    private List<Ticket> availableTickets = new ArrayList<>(); // Store available tickets
    private Map<Integer, Ticket> bookedTickets = new HashMap<>(); // Store booked tickets using HashMap

    public DemoRestController() {
        System.out.println("Constructor DemoRestController()");
    }

    @GetMapping("/abcd")
    String met() {
        System.out.println("-----j-----");
        return "HelloWorld";
    }

    @GetMapping("/ticket")
    Ticket getUser(@RequestParam("tid") int ticketid) {
        return availableTickets.stream()
                .filter(ticket -> ticket.getId() == ticketid)
                .findFirst()
                .orElse(null);
    }

    @PostMapping("/book")
    Ticket bookTicket(@RequestBody Ticket ticket) {
        int ticketId = bookedTickets.size() + 1; // Generate unique ID for booked tickets
        ticket.setId(ticketId);
        bookedTickets.put(ticketId, ticket); // Add the ticket to the HashMap
        return ticket;
    }

    @DeleteMapping("/cancel")
    String cancelTicket(@RequestParam("id") int ticketid) {
        if (bookedTickets.remove(ticketid) != null) {
            return "Ticket with id " + ticketid + " is cancelled";
        } else {
            return "Ticket with id " + ticketid + " not found";
        }
    }

    @GetMapping("/booked-tickets")
    List<Ticket> getBookedTickets() {
        return new ArrayList<>(bookedTickets.values()); // Return the list of booked tickets
    }
}
