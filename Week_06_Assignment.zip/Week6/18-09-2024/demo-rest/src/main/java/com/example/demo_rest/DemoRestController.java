package com.example.demo_rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController

public class DemoRestController {
	public DemoRestController() {
		System.out.println("Constructor DemoCOntroller()");
	}
	@GetMapping("/abcd")
	String met() {
		System.out.println("-----j-----");
		return "HelloWorld";
	}
@GetMapping("/person")
User getUser() {
return new User(1,"Some User", "Some addr");
}
}
